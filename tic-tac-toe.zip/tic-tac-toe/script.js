
let area = document.getElementById('area')
let item = document.getElementsByClassName('item')

for(let i = 1; i <= 9; i++){
    area.innerHTML += "<div class='item'></div>"
}

let step = ''
let spanWho = document.getElementById('spanWho')
let winner = ''

const move = () => {
    if (step === 'circle'){
        step = 'krest';
        spanWho.innerText = 'Крестики';
    } else {
        step = 'circle'
        spanWho.innerText = 'Нолики';
    }
}

move()

let Item = document.querySelectorAll('.item')
let cnt = 0;

Item.forEach((elem) => {
    elem.addEventListener('click', () => {
        if(!elem.classList.contains('circle') && !elem.classList.contains('krest')){
            elem.classList.add(step)
            if (step=='krest'){
                elem.innerText = 'X'
            }
            if (step=='circle'){
                elem.innerText = '0'
            }
        }
        cnt++;
        move()
        circleWin()
        krestWin()
        noWin()
    })
})

let win =
    [
        [0,1,2],
        [0,4,8],
        [2,4,6],
        [3,4,5],
        [6,7,8],
        [0,3,6],
        [1,4,7],
        [2,5,8]
    ]

let circleWin = ()=>{
    for(let i = 0; i < win.length; i++){
        if(
            Item[win[i][0]].classList.contains('circle') &&
            Item[win[i][1]].classList.contains('circle') &&
            Item[win[i][2]].classList.contains('circle')
        ){
            Item[win[i][0]].classList.add('winColor')
            Item[win[i][1]].classList.add('winColor')
            Item[win[i][2]].classList.add('winColor')
            winner = "Нулики"
            endGame(winner)
            return 1
        }
    }
}

let krestWin = ()=>{
    for(let i = 0; i < win.length; i++){
        if(
            Item[win[i][0]].classList.contains('krest') &&
            Item[win[i][1]].classList.contains('krest') &&
            Item[win[i][2]].classList.contains('krest')
        ){
            Item[win[i][0]].classList.add('winColor')
            Item[win[i][1]].classList.add('winColor')
            Item[win[i][2]].classList.add('winColor')
            winner = "Крестики"
            endGame(winner)
            return 1
        }
    }
}

let noWin = () =>{
    if (!krestWin() && !circleWin() && (cnt >=9)){
        winner = "Ничья"
        endGame(winner)
    }
}

let Winner = document.getElementById('winner')
let spanWin = document.getElementById('spanWin')
let btnNewGame = document.getElementById('BtnNewGame')

let Area = document.getElementById('area')

let endGame = (winner)=>{
    Area.style.pointerEvents = 'none';
    Winner.style.display = 'flex'
    spanWin.innerText = winner;
}

btnNewGame.addEventListener('click',()=>{
    document.location.reload()
})